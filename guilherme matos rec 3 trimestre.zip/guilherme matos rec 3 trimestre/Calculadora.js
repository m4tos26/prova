const calcular = function() {
    var hora = parseInt(document.getElementById('Hora'));
    var quantidade = parseInt(document.getElementById('Quantidade'));
    var final = hora * quantidade * 52;
    document.getElementByID('Resultado').innerHTML = final;
}
hora * quant_hora * 6 * 4 = salario bruto
salario_bruto - irrf
